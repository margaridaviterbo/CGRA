/**
*MyUnitCube
* @param gl {WebGLRenderingContext}
* @constructor
*/

function MyUnitCube(scene) {
  CGFobject.call(this, scene);
  this.initBuffers();
};

// subclass extends superclass
MyUnitCube.prototype = Object.create(CGFobject.prototype);
MyUnitCube.prototype.constructor = MyUnitCube;

MyUnitCube.prototype.initBuffers = function() {
  this.vertices = [
    0.5, 0.5, 0.5,
    -0.5, 0.5, 0.5,
    -0.5, -0.5, 0.5,
    0.5, -0.5, 0.5,
    0.5, -0.5, -0.5,
    0.5, 0.5, -0.5,
    -0.5, 0.5, -0.5,
    -0.5, -0.5, -0.5
  ];

  this.indices = [
    0,1,2,
    0,2,3,
    0,3,4,
    5,0,4,
    5,4,7,
    6,5,7,
    1,6,7,
    1,7,2,
    6,1,0,
    5,6,0,
    7,3,2,
    7,4,3
  ];

  this.primitiveType = this.scene.gl.TRIANGLES;
  this.initGLBuffers();
};
