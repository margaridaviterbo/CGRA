/**
 * MyClock
 * @constructor
 */
 function MySubmarine(scene) {
 	CGFobject.call(this,scene);

     this.triangle = new MyTriangle(scene);

     this.rotationAngle = Math.PI*4/5;

     this.positionX = 5;
     this.positionZ = 5;
 };

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor = MySubmarine;

MySubmarine.prototype.display = function(){

    this.scene.pushMatrix();
        this.scene.translate(this.positionX, 0, this.positionZ);
        this.scene.rotate(this.rotationAngle, 0, 1, 0);
        this.triangle.display();
    this.scene.popMatrix();
   
}

MySubmarine.prototype.rotate = function(orientation){
   
    this.rotationAngle += Math.PI / 180 * orientation * this.scene.speed;
}

MySubmarine.prototype.move = function(direction){
    //forward
    var x = Math.sin(this.rotationAngle);
    var z = Math.cos(this.rotationAngle);
    console.log(x + "  " + z);

    if (direction == 1){
        this.positionX += x*0.05*this.scene.speed;
        this.positionZ += z*0.05*this.scene.speed;
    }
    else if (direction == -1){
        this.positionX -= x*0.05*this.scene.speed;
        this.positionZ -= z*0.05*this.scene.speed;
    }
}

//not used
MySubmarine.prototype.setAngle = function(angle){
    
    this.rotationAngle += angle * Math.PI / 180;

}

MySubmarine.prototype.setVelocity = function(velocity){

    this.linearVelocity = velocity;
}