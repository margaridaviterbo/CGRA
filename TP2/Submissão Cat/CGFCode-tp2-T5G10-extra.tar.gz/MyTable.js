/**
*MyTable
* @param gl {WebGLRenderingContext}
* @constructor
*/

function MyTable(scene) {
  CGFobject.call(this, scene);
  this.cube = new MyUnitCubeQuad(this.scene);

  //table material
	this.tableMaterial = new CGFappearance(scene);
	this.tableMaterial.setAmbient(0.3,0.3,0.3,1);
	this.tableMaterial.setDiffuse(0.59,0.44,0.2,1);
	this.tableMaterial.setSpecular(0.1,0.1,0.1,1);	
	this.tableMaterial.setShininess(120);

	//table legs material
	this.legsMaterial = new CGFappearance(scene);
	this.legsMaterial.setAmbient(0.3,0.3,0.3,1);
	this.legsMaterial.setDiffuse(0.75,0.75,0.75,1);
	this.legsMaterial.setSpecular(0.7,0.7,0.7,1);	
	this.legsMaterial.setShininess(120);
};

// subclass extends superclass
MyTable.prototype = Object.create(CGFobject.prototype);
MyTable.prototype.constructor = MyTable;

MyTable.prototype.display = function () {

  //tampo
  this.scene.pushMatrix();
    this.scene.translate(0, 3.65, 0);
    this.scene.scale(5, 0.3, 3);
    this.tableMaterial.apply();
    this.cube.display();
  this.scene.popMatrix();

  //perna esquerda trás
  this.scene.pushMatrix();
    this.scene.translate(-2.35, 1.75, -1.35);
    this.scene.scale(0.3, 3.5, 0.3);
    this.legsMaterial.apply();
    this.cube.display();
  this.scene.popMatrix();

  //perna direita trás
  this.scene.pushMatrix();
    this.scene.translate(2.35, 1.75, -1.35);
    this.scene.scale(0.3, 3.5, 0.3);
    this.cube.display();
  this.scene.popMatrix();

  //perna esquerda frente
  this.scene.pushMatrix();
    this.scene.translate(-2.35, 1.75, 1.35);
    this.scene.scale(0.3, 3.5, 0.3);
    this.cube.display();
  this.scene.popMatrix();

  //perna direita frente
  this.scene.pushMatrix();
    this.scene.translate(2.35, 1.75, 1.35);
    this.scene.scale(0.3, 3.5, 0.3);
    this.cube.display();
  this.scene.popMatrix();

  

};
